import React from 'react'
import TransactionPage from './TransactionPage'

export default function TransactionPageHolderForStation() {
  return (
    <div>
      <TransactionPage title={"Transactions History"}/>
    </div>
  )
}
