// constants.js
export const ACCESS_TOKEN = 'access_token';
export const REFRESH_TOKEN = 'refresh_token';
export const USER_TYPE = 'user_type';
export const USER_DATA = 'user_data';
export const STATION_ID = 'station_ID';
export const PASSENGER_ID = 'passenger_ID';